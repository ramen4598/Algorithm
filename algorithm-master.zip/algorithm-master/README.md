# 구미_4반_김의근_알고과제

|날짜|과제|문제|
|:------:|:-------------------------:|:----------------------------------:|
|2024.01.30|[BOJ1244.java](./240130/BOJ1244.java)|[백준 1244번 스위치 켜고 쓰기](https://www.acmicpc.net/problem/1244)|
|2024.01.31|[SWEA1954.java](./240131/SWEA1954.java)|[SWEA 1954번 달팽이 숫자](https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AV5PobmqAPoDFAUq)|
|2024.02.01|[SWEA2001](./240201/SWEA2001.java),[SWEA2001_1](./240201/SWEA2001_1.java)|[SWEA 2001번 파리퇴치](https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AV5PzOCKAigDFAUq)|
|2024.02.02|[BOJ2164.java](./240202/BOJ2164.java)|[백준 2164번 카드2](https://www.acmicpc.net/problem/2164)|
|2024.02.05|[SWEA1228.java](./240205/SWEA1228.java)|[SWEA 1228번 암호문1](https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AV14w-rKAHACFAYD)|
|2024.02.06|[SWEA9229.java](./240206/SWEA9229.java)|[SWEA 9229번 한빈이와 Spot Mart](https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AW8Wj7cqbY0DFAXN)|
|2024.02.07|[BOJ2563.java](./240207/BOJ2563.java)|[백준 2563번 색종이](https://www.acmicpc.net/problem/2563)|
|2024.02.13|[BOJ2839.java](./240213/BOJ2839.java)|[백준 2839번 설탕 배달](https://www.acmicpc.net/problem/2839)|
|2024.02.14|[BOJ1992.java](./240214/BOJ1992.java)|[백준 1992번 쿼드 트리](https://www.acmicpc.net/problem/1992)|
|2024.02.15|[SWEA1873.java](./240215/SWEA1873.java)|[SWEA 1873번 상호의 배틀필드](https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AV5LyE7KD2ADFAXc)|
|2024.02.16|[SWEA1227.java](./240216/SWEA1227.java)|[SWEA 1227번 미로 2](https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AV14wL9KAGkCFAYD)|
|2024.02.20|[BOJ15686.java](./240220/BOJ15686.java),[BOJ15686_2.java](./240220/BOJ15686_2.java)|[백준 15686번 치킨 배달](https://www.acmicpc.net/problem/15686)|
|2024.02.21|[BOJ1759.java](./240221/BOJ1759.java),[BOJ1759_2.java](./240221/BOJ1759_2.java)|[백준 1759번 암호 만들기](https://www.acmicpc.net/problem/1759)|
|2024.02.22|[SWEA1238.java](./240222/SWEA1238.java)|[SWEA 1238번 Contact](https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AV15B1cKAKwCFAYD)|
|2024.02.23|[BOJ15961.java](./240223/BOJ15961.java)|[백준 15961번 회전 초밥](https://www.acmicpc.net/problem/15961)|
|2024.02.27|[BOJ4485.java](./240227/BOJ4485.java), [BOJ4485_2.java](./240227/BOJ4485_2.java)|[백준 4458번 녹색 옷 입은 애가 젤다지?](https://www.acmicpc.net/problem/4485)|
|2024.02.28|[SWEA1767_2.java](./240228/SWEA1767_2.java)|[SWEA 1767번 프로세서 연결하기](https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AV4suNtaXFEDFAUf)|
|2024.02.29|[SWEA5653.java](./240229/SWEA5653.java)|[SWEA 5653번 프로세서 연결하기](https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AWXRJ8EKe48DFAUo)|
|2024.03.26|[BOJ4485_3.java](./240326/BOJ4485_3.java)|[백준 4458번 녹색 옷 입은 애가 젤다지?](https://www.acmicpc.net/problem/4485)|
|2024.03.27|[BOJ2239_3.java](./240327/BOJ2239.java)|[백준 2239번 스도쿠](https://www.acmicpc.net/problem/2239)|
|2024.03.28|[BOJ3055java](./240328/BOJ3055.java)|[백준 3055번 탈출](https://www.acmicpc.net/problem/3055)|
|2024.03.29|[SWEA5656.java](./240329/SWEA5656.java)|[SWEA 5656번 벽돌 깨기](https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AWXRQm6qfL0DFAUo)|
|2024.04.01|[SWEA5607.java](./240401/SWEA5607.java)|[SWEA 5607번 조합](https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AWXGKdbqczEDFAUo)|
|2024.04.02|[SWEA5604.java](./240402/SWEA5604.java)|[SWEA 5604번 구간합](https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AWXGGNB6cnEDFAUo)|
|2024.04.03|[SWEA5643.java](./240403/SWEA5643.java)|[SWEA 5643번 키순서](https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AWXQsLWKd5cDFAUo)|
|2024.04.04|[SWEA1249.java](./240404/SWEA1249.java)|[SWEA 1249번 보급로](https://swexpertacademy.com/main/code/problem/problemDetail.do?contestProbId=AV15QRX6APsCFAYD)|

---

<!---
|2024.02.01|[]()|[]()|
--->
