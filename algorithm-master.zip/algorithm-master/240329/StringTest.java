
public class StringTest {

	public static void main(String[] args) {
		String a = "이예림 바보";
		String b = a;
		System.out.println(a.hashCode() +" "+ b.hashCode());
	}

}
