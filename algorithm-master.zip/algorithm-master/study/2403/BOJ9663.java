import java.util.StringTokenizer;
import java.io.*;

class BOJ9663 {
  static int N;
  static void main(String[] args){
    
  }
}
